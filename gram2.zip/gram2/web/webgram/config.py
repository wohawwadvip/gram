import os 

class Config:

    class config:
        APP_ID = 208047
        API_HASH = "9486498c749aaf2b37019c9366fecc9a"
        BOT_TOKEN = "2036130706:AAGgsjjOxCTYmN-As5MH2hLqvBu5fgeHLPI"
        STATS_CHANNEL = -1001586954849
        HOST = "127.0.0.1"
        PORT = os.getenv('PORT')
        ROOT_URI = f"http://tr.teliran.cf"